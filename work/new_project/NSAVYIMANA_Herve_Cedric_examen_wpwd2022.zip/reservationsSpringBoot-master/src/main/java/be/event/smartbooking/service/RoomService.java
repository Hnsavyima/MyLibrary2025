package be.event.smartbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import be.event.smartbooking.errorHandler.BusinessException;
import be.event.smartbooking.model.Location;
import be.event.smartbooking.model.Room;
import be.event.smartbooking.repository.RoomRepos;

@Service
public class RoomService {

    @Autowired
    private RoomRepos repository;

    public List<Room> getAll() {
        return repository.findAll();
    }

    public Room get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new BusinessException("Salle introuvable avec l'ID : " + id, HttpStatus.NOT_FOUND));
    }

    public Room get(String id) {
        try {
            return get(Long.parseLong(id));
        } catch (NumberFormatException e) {
            throw new BusinessException("Format d'identifiant invalide : " + id, HttpStatus.BAD_REQUEST);
        }
    }

    public List<Room> getByLocation(Location location) {
        return repository.findByLocation(location);
    }

}
