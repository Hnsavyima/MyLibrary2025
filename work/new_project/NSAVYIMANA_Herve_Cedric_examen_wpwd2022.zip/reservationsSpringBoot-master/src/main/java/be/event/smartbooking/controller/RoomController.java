package be.event.smartbooking.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import be.event.smartbooking.model.Room;
import be.event.smartbooking.model.Show;
import be.event.smartbooking.service.RepresentationService;
import be.event.smartbooking.service.RoomService;

@Controller
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    private RoomService roomService;

    @Autowired
    private RepresentationService representationService;

    @GetMapping("/{id}/shows")
    public String showsByRoom(Model model, @PathVariable("id") Long id) {
        Room room = roomService.get(id);
        List<Show> shows = representationService.getFromRoom(room)
                .stream()
                .map(r -> r.getShow())
                .distinct()
                .collect(Collectors.toList());
        model.addAttribute("room", room);
        model.addAttribute("shows", shows);
        model.addAttribute("title", "Spectacles de la salle " + room.getName());
        return "room/shows";
    }

}
