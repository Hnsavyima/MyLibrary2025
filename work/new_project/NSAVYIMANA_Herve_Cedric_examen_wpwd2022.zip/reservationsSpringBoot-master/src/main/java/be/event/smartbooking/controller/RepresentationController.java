package be.event.smartbooking.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import be.event.smartbooking.model.Representation;
import be.event.smartbooking.model.Room;
import be.event.smartbooking.model.Show;
import be.event.smartbooking.service.RepresentationService;
import be.event.smartbooking.service.RoomService;
import be.event.smartbooking.service.ShowService;

@Controller
public class RepresentationController {

    @Autowired
    RepresentationService service;

    @Autowired
    ShowService showService;

    @Autowired
    RoomService roomService;

    @GetMapping("/representations")
    public String index(Model model) {
        List<Representation> representations = service.getAll();
        model.addAttribute("representations", representations);
        model.addAttribute("title", "Liste des representations");
        return "representation/index";
    }

    @GetMapping("/representations/{id}")
    public String show(Model model, @PathVariable("id") String id) {
        Representation representation = service.get(id);
        model.addAttribute("representation", representation);
        model.addAttribute("title", "Fiche d'une representation");
        return "representation/show";
    }

    @GetMapping("/representations/add")
    @PreAuthorize("hasRole('ADMIN')")
    public String addForm(Model model) {
        model.addAttribute("shows", showService.getAllForAdmin());
        model.addAttribute("rooms", roomService.getAll());
        model.addAttribute("title", "Ajouter une représentation");
        return "representation/add";
    }

    @PostMapping("/representations/add")
    @PreAuthorize("hasRole('ADMIN')")
    public String addSubmit(
            @RequestParam Long showId,
            @RequestParam Long roomId,
            @RequestParam String when,
            Model model) {

        LocalDateTime dateTime = LocalDateTime.parse(when);
        Room room = roomService.get(roomId);

        if (service.isRoomOccupied(room, dateTime)) {
            model.addAttribute("shows", showService.getAllForAdmin());
            model.addAttribute("rooms", roomService.getAll());
            model.addAttribute("title", "Ajouter une représentation");
            model.addAttribute("errorMessage", "Cette salle est déjà occupée à ce moment.");
            return "representation/add";
        }

        Show show = showService.get(showId);
        Representation representation = Representation.builder()
                .show(show)
                .room(room)
                .when(dateTime)
                .build();
        service.add(representation);

        return "redirect:/shows/" + show.getSlug();
    }

}
