package be.event.smartbooking.repository;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import be.event.smartbooking.model.Representation;
import be.event.smartbooking.model.Room;
import be.event.smartbooking.model.Show;

public interface RepresentationRepos extends JpaRepository<Representation, Long> {

    List<Representation> findByShow(Show show);

    List<Representation> findByRoom(Room room);

    List<Representation> findByWhen(LocalDateTime when);

    boolean existsByRoomAndWhen(Room room, LocalDateTime when);

}
