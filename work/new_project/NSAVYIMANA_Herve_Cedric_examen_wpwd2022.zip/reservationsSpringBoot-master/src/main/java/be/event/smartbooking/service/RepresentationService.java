package be.event.smartbooking.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import be.event.smartbooking.errorHandler.BusinessException;
import be.event.smartbooking.model.Representation;
import be.event.smartbooking.model.Room;
import be.event.smartbooking.model.Show;
import be.event.smartbooking.repository.RepresentationRepos;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional(readOnly = true)
public class RepresentationService {

    @Autowired
    private RepresentationRepos repository;

    public List<Representation> getAll() {
        return StreamSupport.stream(repository.findAll().spliterator(), false)
                .collect(Collectors.toList());
    }

    public Representation get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new BusinessException("Séance (représentation) introuvable avec l'ID : " + id,
                        HttpStatus.NOT_FOUND));
    }

    public Representation get(String id) {
        try {
            return get(Long.parseLong(id));
        } catch (NumberFormatException e) {
            throw new BusinessException("Format d'identifiant invalide : " + id, HttpStatus.BAD_REQUEST);
        }
    }

    @Transactional
    public void add(Representation representation) {
        log.info("Ajout d'une nouvelle séance pour le spectacle : {}",
                representation.getShow() != null ? representation.getShow().getTitle() : "Inconnu");
        repository.save(representation);
    }

    @Transactional
    public void update(Long id, Representation updatedRepresentation) {
        Representation existing = get(id);
        existing.setWhen(updatedRepresentation.getWhen());
        existing.setRoom(updatedRepresentation.getRoom());
        existing.setShow(updatedRepresentation.getShow());
        repository.save(existing);
        log.info("Séance ID {} mise à jour.", id);
    }

    @Transactional
    public void delete(Long id) {
        Representation representation = get(id);
        repository.delete(representation);
        log.warn("Séance ID {} supprimée définitivement.", id);
    }

    public boolean isRoomOccupied(Room room, LocalDateTime when) {
        return repository.existsByRoomAndWhen(room, when);
    }

    public List<Representation> getFromRoom(Room room) {
        return repository.findByRoom(room);
    }

    public List<Representation> getFromShow(Show show) {
        return repository.findByShow(show);
    }
}
