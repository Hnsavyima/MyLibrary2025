package be.event.smartbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import be.event.smartbooking.model.Location;
import be.event.smartbooking.service.LocationService;
import be.event.smartbooking.service.RoomService;

@Controller
@RequestMapping("/locations")
public class LocationController {

    @Autowired
    private LocationService locationService;

    @Autowired
    private RoomService roomService;

    @GetMapping
    public String index(Model model) {
        List<Location> locations = locationService.getAll();
        model.addAttribute("locations", locations);
        model.addAttribute("title", "Liste des lieux de spectacle");
        return "location/index";
    }

    @GetMapping("/{id}")
    public String show(Model model, @PathVariable("id") String id) {
        Location location = locationService.get(id);
        model.addAttribute("location", location);
        model.addAttribute("rooms", roomService.getByLocation(location));
        model.addAttribute("title", "Salles de " + location.getDesignation());
        return "location/show";
    }

}
