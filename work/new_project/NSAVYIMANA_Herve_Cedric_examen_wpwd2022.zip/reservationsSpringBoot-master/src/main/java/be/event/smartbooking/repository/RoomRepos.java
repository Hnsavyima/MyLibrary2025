package be.event.smartbooking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import be.event.smartbooking.model.Location;
import be.event.smartbooking.model.Room;

public interface RoomRepos extends JpaRepository<Room, Long> {

    List<Room> findByLocation(Location location);

    List<Room> findByLocationId(Long locationId);

}
