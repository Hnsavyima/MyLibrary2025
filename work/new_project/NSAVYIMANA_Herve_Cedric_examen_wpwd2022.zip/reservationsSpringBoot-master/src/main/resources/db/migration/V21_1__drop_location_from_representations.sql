ALTER TABLE `representations` DROP FOREIGN KEY `representations_location_id_a6832141_fk_locations_id`;
ALTER TABLE `representations` DROP KEY `representations_location_id_a6832141_fk_locations_id`;
ALTER TABLE `representations` DROP COLUMN `location_id`;
