INSERT INTO `rooms` (`id`, `name`, `seats`, `location_id`) VALUES
(1, 'Grande Salle', 600, 1),
(2, 'Salle Studio', 120, 1),
(3, 'Salle Principale', 400, 2),
(4, 'Salle de Répétition', 80, 2),
(5, 'Salle La Samaritaine A', 250, 3),
(6, 'Salle La Samaritaine B', 100, 3),
(7, 'Grande Scène Magh', 500, 4),
(8, 'Salle Annexe Magh', 150, 4);
