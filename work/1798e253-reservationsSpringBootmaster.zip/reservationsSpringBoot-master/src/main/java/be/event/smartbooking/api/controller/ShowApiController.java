package be.event.smartbooking.api.controller;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.context.i18n.LocaleContextHolder;

import be.event.smartbooking.dto.ArtistDTO;
import be.event.smartbooking.dto.PriceDTO;
import be.event.smartbooking.dto.RepresentationDTO;
import be.event.smartbooking.dto.ReviewDTO;
import be.event.smartbooking.dto.ShowCreateRequest;
import be.event.smartbooking.dto.ShowDTO;
import be.event.smartbooking.dto.ShowUpdateDTO;
import be.event.smartbooking.dto.TagDTO;
import be.event.smartbooking.dto.VideoDTO;
import be.event.smartbooking.model.ArtistType;
import be.event.smartbooking.model.Price;
import be.event.smartbooking.model.Representation;
import be.event.smartbooking.model.Review;
import be.event.smartbooking.model.Show;
import be.event.smartbooking.repository.ArtistTypeRepos;
import be.event.smartbooking.repository.LocationRepos;
import be.event.smartbooking.repository.UserRepos;
import be.event.smartbooking.service.FileService;
import be.event.smartbooking.service.ShowService;
import be.event.smartbooking.service.TranslationService;

@RestController
@RequestMapping("/api/shows")
public class ShowApiController {

        @Autowired
        private ShowService showService;

        @Autowired
        private LocationRepos locationRepos;

        @Autowired
        private ArtistTypeRepos artistTypeRepos;

        @Autowired
        private FileService fileService;

        @Autowired
        private TranslationService translationService;

        @Autowired
        private UserRepos userRepos;

        /**
         * GET /api/shows : Catalogue public (Uniquement CONFIRME)
         */
        @GetMapping
        @Transactional(readOnly = true)
        public ResponseEntity<List<ShowDTO>> getAll() {
                try {
                        List<Show> shows = showService.getAll(); // Utilise le filtre CONFIRME du service
                        List<ShowDTO> dtos = shows.stream()
                                        .map(this::safeConvertToDto)
                                        .collect(Collectors.toList());
                        return ResponseEntity.ok(dtos);
                } catch (Exception e) {
                        return ResponseEntity.internalServerError().build();
                }
        }

        /**
         * GET /api/shows/admin : Liste complète pour l'Admin (CONFIRME + A_CONFIRMER)
         */
        @GetMapping("/admin")
        @Transactional(readOnly = true)
        public ResponseEntity<List<ShowDTO>> getAllForAdmin() {
                try {
                        List<Show> shows = showService.getAllForAdmin();
                        List<ShowDTO> dtos = shows.stream()
                                        .map(this::safeConvertToDto)
                                        .collect(Collectors.toList());
                        return ResponseEntity.ok(dtos);
                } catch (Exception e) {
                        return ResponseEntity.internalServerError().build();
                }
        }

        /**
         * PUT /api/shows/{id}/confirm : Action de validation par l'Admin
         */
        @PutMapping("/{id}/confirm")
        public ResponseEntity<?> confirmShow(@PathVariable Long id) {
                // 1. On effectue la modification en base via le service
                Show updatedShow = showService.confirmShow(id);

                // 2. 🚀 LA CORRECTION : On renvoie le DTO au lieu d'une Map manuelle
                // safeConvertToDto s'occupe d'extraire le nom du lieu proprement sans les
                // proxies Hibernate
                return ResponseEntity.ok(safeConvertToDto(updatedShow));
        }

        /**
         * GET /api/shows/{id} : Récupère un spectacle par son ID
         */
        @GetMapping("/{id}")
        @Transactional(readOnly = true)
        public ResponseEntity<ShowDTO> getById(@PathVariable Long id) {
                Show show = showService.get(id);
                if (show == null) {
                        return ResponseEntity.notFound().build();
                }
                return ResponseEntity.ok(safeConvertToDto(show));
        }

        /**
         * GET /api/shows/slug/{slug} : Récupère un spectacle par son slug
         * Utilisé pour les URLs du frontend (ex: /show/mon-spectacle)
         */
        @GetMapping("/slug/{slug}")
        @Transactional(readOnly = true)
        public ResponseEntity<ShowDTO> getBySlug(@PathVariable String slug) {
                try {
                        Show show = showService.findBySlug(slug); // Utilise votre service existant

                        if (show == null) {
                                return ResponseEntity.notFound().build();
                        }

                        return ResponseEntity.ok(safeConvertToDto(show)); // Utilise votre conversion sécurisée
                } catch (Exception e) {
                        e.printStackTrace();
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                }
        }

        /**
         * GET /api/shows/search?query=... : Recherche par titre (Issue #1)
         */
        @GetMapping("/search")
        @Transactional(readOnly = true)
        public ResponseEntity<List<ShowDTO>> search(
                        @RequestParam(required = false) String title,
                        @RequestParam(required = false) String location,
                        @RequestParam(required = false) LocalDateTime start,
                        @RequestParam(required = false) LocalDateTime end) {

                try {
                        // Appel au service avec les 3 paramètres
                        List<Show> shows = showService.search(title, location, start, end);

                        List<ShowDTO> dtos = shows.stream()
                                        .map(this::safeConvertToDto)
                                        .collect(Collectors.toList());

                        return ResponseEntity.ok(dtos);
                } catch (Exception e) {
                        e.printStackTrace();
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                }
        }

        /**
         * GET /api/shows/search-by-tag?keyword=... : Recherche par mot-clé (tag)
         */
        @GetMapping("/search-by-tag")
        @Transactional(readOnly = true)
        public ResponseEntity<Map<String, Object>> searchByTag(@RequestParam String keyword) {
                try {
                        List<Show> shows = showService.searchByTag(keyword);
                        List<ShowDTO> dtos = shows.stream().map(this::safeConvertToDto).collect(Collectors.toList());
                        Map<String, Object> result = new HashMap<>();
                        result.put("total", dtos.size());
                        result.put("keyword", keyword);
                        result.put("shows", dtos);
                        return ResponseEntity.ok(result);
                } catch (Exception e) {
                        return ResponseEntity.internalServerError().build();
                }
        }

        /**
         * GET /api/shows/without-tag/{tag} : Route personnalisée — spectacles sans ce tag
         */
        @GetMapping("/without-tag/{tag}")
        @Transactional(readOnly = true)
        public ResponseEntity<Map<String, Object>> getShowsWithoutTag(@PathVariable String tag) {
                try {
                        List<Show> shows = showService.getShowsWithoutTag(tag);
                        List<ShowDTO> dtos = shows.stream().map(this::safeConvertToDto).collect(Collectors.toList());
                        Map<String, Object> result = new HashMap<>();
                        result.put("total", dtos.size());
                        result.put("excludedTag", tag);
                        result.put("shows", dtos);
                        return ResponseEntity.ok(result);
                } catch (Exception e) {
                        return ResponseEntity.internalServerError().build();
                }
        }

        /**
         * POST /api/shows : Crée un nouveau spectacle (Issue #3)
         */
        @PostMapping(consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
        public ResponseEntity<ShowDTO> create(
                        @RequestPart("show") ShowCreateRequest request,
                        @RequestPart(value = "poster", required = false) MultipartFile file,
                        Principal principal) { // 👈 Injecte le Principal ici
                try {
                        // 1. On construit l'entité Show de base
                        Show show = Show.builder()
                                        .title(request.getTitle())
                                        .description(request.getDescription())
                                        .bookable(request.isBookable())
                                        .build();

                        // 2. On lie le Producteur (Utilisateur connecté) 🚀
                        if (principal != null) {
                                String login = principal.getName();
                                // On récupère l'objet User complet depuis ton repository d'utilisateurs
                                be.event.smartbooking.model.User currentUser = userRepos.findByLogin(login);
                                show.setProducer(currentUser); // On assigne le producteur au show
                        }

                        // 3. On lie le lieu (Location)
                        if (request.getLocationId() != null) {
                                locationRepos.findById(request.getLocationId())
                                                .ifPresent(show::setLocation);
                        }

                        // 4. On lie les artistes
                        if (request.getArtistTypeIds() != null) {
                                List<ArtistType> artists = artistTypeRepos.findAllById(request.getArtistTypeIds());
                                artists.forEach(show::addArtistType);
                        }

                        // 5. On gère l'image
                        if (file != null && !file.isEmpty()) {
                                String imageUrl = fileService.save(file);
                                show.setPosterUrl(imageUrl);
                        }

                        showService.add(show);
                        return new ResponseEntity<>(safeConvertToDto(show), HttpStatus.CREATED);
                } catch (Exception e) {
                        e.printStackTrace();
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                }
        }

        /**
         * PUT /api/shows/{id} : Met à jour un spectacle existant
         */
        @PutMapping(value = "/{id}", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
        public ResponseEntity<ShowDTO> update(
                        @PathVariable Long id,
                        @RequestPart("show") ShowUpdateDTO request,
                        @RequestPart(value = "poster", required = false) MultipartFile file) {

                try { // <--- IL MANQUAIT CE BLOC TRY ICI
                      // 1. On récupère le spectacle existant
                        Show show = showService.get(id);
                        if (show == null) {
                                return ResponseEntity.notFound().build();
                        }

                        // 2. Mapping du DTO vers l'entité
                        show.setTitle(request.getTitle());
                        show.setDescription(request.getDescription());
                        show.setBookable(request.isBookable());

                        // 3. Gestion du lieu
                        if (request.getLocationId() != null) {
                                locationRepos.findById(request.getLocationId()).ifPresent(show::setLocation);
                        }

                        // 4. Gestion des artistes
                        show.getArtistTypes().clear();
                        if (request.getArtistTypeIds() != null) {
                                List<ArtistType> artists = artistTypeRepos.findAllById(request.getArtistTypeIds());
                                artists.forEach(show::addArtistType);
                        }

                        // 5. Gestion de l'image (IOException possible ici)
                        if (file != null && !file.isEmpty()) {
                                String imageUrl = fileService.save(file);
                                show.setPosterUrl(imageUrl);
                        }

                        // 6. Sauvegarde et retour
                        showService.update(id, show);
                        return ResponseEntity.ok(safeConvertToDto(show));

                } catch (IOException e) {
                        // Erreur spécifique au stockage du fichier
                        e.printStackTrace();
                        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                } catch (Exception e) {
                        // Erreur générale (Logique métier, IDs inexistants, etc.)
                        e.printStackTrace();
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                }
        }

        @PutMapping("/{id}/revoke")
        public ResponseEntity<?> revokeShow(@PathVariable Long id) {
                // 1. Le service passe le statut à A_CONFIRMER en base
                Show updatedShow = showService.revokeShow(id);

                // 2. 🚀 On renvoie le DTO propre
                // Cela évite tout problème de sérialisation Hibernate et reste cohérent avec
                // "confirm"
                return ResponseEntity.ok(safeConvertToDto(updatedShow));
        }

        /**
         * DELETE /api/shows/{id} : Supprime un spectacle
         */
        @DeleteMapping("/{id}")
        public ResponseEntity<Void> delete(@PathVariable Long id) {
                Show existingShow = showService.get(id);
                if (existingShow == null) {
                        return ResponseEntity.notFound().build();
                }
                showService.delete(id);
                return ResponseEntity.noContent().build();
        }

        @GetMapping("/my-shows")
        @Transactional(readOnly = true)
        public ResponseEntity<List<ShowDTO>> getMyShows(Principal principal) {
                try {
                        // 1. On récupère le login de l'utilisateur connecté via Spring Security
                        String login = principal.getName();

                        // 2. On demande au service les spectacles liés à ce login
                        List<Show> shows = showService.getByUserLogin(login);

                        // 3. Conversion en DTO (en utilisant ta méthode safeConvertToDto déjà
                        // existante)
                        List<ShowDTO> dtos = shows.stream()
                                        .map(this::safeConvertToDto)
                                        .collect(Collectors.toList());

                        return ResponseEntity.ok(dtos);
                } catch (Exception e) {
                        return ResponseEntity.internalServerError().build();
                }
        }

        /**
         * Transformation sécurisée de l'entité Show vers ShowDTO.
         * Translates title and description to the request locale when translation is
         * available.
         */
        private ShowDTO safeConvertToDto(Show show) {
                String targetLang = LocaleContextHolder.getLocale().getLanguage();
                String sourceLang = "fr";
                String title = translateIfNeeded(show.getTitle(), sourceLang, targetLang);
                String description = translateIfNeeded(show.getDescription(), sourceLang, targetLang);
                String locationDesignation = translateIfNeeded(
                                show.getLocation() != null ? show.getLocation().getDesignation() : null,
                                sourceLang, targetLang);
                if (locationDesignation == null || locationDesignation.isBlank()) {
                        locationDesignation = translateIfNeeded("Lieu non défini", sourceLang, targetLang);
                }

                return ShowDTO.builder()
                                .id(show.getId())
                                .slug(show.getSlug())
                                .title(title)
                                .description(description)
                                .posterUrl(show.getPosterUrl())
                                .bookable(show.isBookable())
                                .status(show.getStatus())

                                // --- DONNÉES POUR LE FORMULAIRE ---
                                .locationId(show.getLocation() != null ? show.getLocation().getId() : null)
                                .artistTypeIds(show.getArtistTypes() != null
                                                ? show.getArtistTypes().stream().map(at -> at.getId()).toList()
                                                : new ArrayList<>())
                                // ----------------------------------

                                .locationDesignation(locationDesignation)
                                .averageRating(show.getAverageRating())
                                .reviewCount(show.getReviewCount())
                                .tags(show.getTags() != null
                                                ? show.getTags().stream()
                                                                .map(t -> TagDTO.builder().id(t.getId()).tag(t.getTag()).build())
                                                                .toList()
                                                : new ArrayList<>())
                                .videos(show.getVideos() != null
                                                ? show.getVideos().stream()
                                                                .map(v -> VideoDTO.builder()
                                                                                .id(v.getId())
                                                                                .title(v.getTitle())
                                                                                .videoUrl(v.getVideoUrl())
                                                                                .showId(show.getId())
                                                                                .showTitle(title)
                                                                                .build())
                                                                .toList()
                                                : new ArrayList<>())

                                .representations(show.getRepresentations() != null ? show.getRepresentations().stream()
                                                .map(rep -> convertRepToDto(rep, title, sourceLang, targetLang))
                                                .toList() : new ArrayList<>())

                                .reviews(show.getReviews() != null
                                                ? show.getReviews().stream()
                                                                .filter(Review::getValidated)
                                                                .map(rev -> convertToReviewDTO(rev, sourceLang,
                                                                                targetLang))
                                                                .toList()
                                                : new ArrayList<>())
                                .artists(show.getArtistTypes() != null ? show.getArtistTypes().stream()
                                                .collect(Collectors.groupingBy(
                                                                at -> at.getArtist(),
                                                                Collectors.mapping(at -> at.getType().getType(),
                                                                                Collectors.toList())))
                                                .entrySet().stream()
                                                .map(entry -> ArtistDTO.builder()
                                                                .id(entry.getKey().getId())
                                                                .firstname(entry.getKey().getFirstname())
                                                                .lastname(entry.getKey().getLastname())
                                                                .types(entry.getValue())
                                                                .build())
                                                .toList() : new ArrayList<>())
                                .build();
        }

        private RepresentationDTO convertRepToDto(Representation rep, String title, String sourceLang,
                        String targetLang) {
                String locationName = "Lieu non défini";

                // 1. On vérifie d'abord si la séance a un lieu spécifique
                if (rep.getLocation() != null) {
                        locationName = rep.getLocation().getDesignation();
                }
                // 2. Sinon, on se rabat sur le lieu par défaut du spectacle
                else if (rep.getShow() != null && rep.getShow().getLocation() != null) {
                        locationName = rep.getShow().getLocation().getDesignation();
                }

                locationName = translateIfNeeded(locationName, sourceLang, targetLang);

                return RepresentationDTO.builder()
                                .id(rep.getId())
                                .when(rep.getWhen())
                                .showTitle(title)
                                .locationName(locationName)
                                // 🚀 ON UTILISE TA MÉTHODE RÉELLE ICI
                                .ticketsSold(rep.getTotalReservedSeats())
                                .prices(rep.getPrices() != null
                                                ? rep.getPrices().stream().map(this::convertPriceToDto).toList()
                                                : new ArrayList<>())
                                .build();
        }

        private ReviewDTO convertToReviewDTO(Review rev, String sourceLang, String targetLang) {
                String comment = translateIfNeeded(rev.getComment(), sourceLang, targetLang);
                return ReviewDTO.builder()
                                .id(rev.getId())
                                .authorLogin(rev.getUser() != null ? rev.getUser().getFirstname() : "Anonyme")
                                .stars(rev.getStars())
                                .comment(comment)
                                .createdAt(rev.getCreatedAt())

                                .build();
        }

        private PriceDTO convertPriceToDto(Price p) {
                return PriceDTO.builder()
                                .id(p.getId())
                                .type(p.getType().toString())
                                .amount(p.getAmount())
                                .build();
        }

        private String translateIfNeeded(String text, String sourceLang, String targetLang) {
                if (text == null || text.isBlank()) {
                        return text;
                }
                if (sourceLang.equalsIgnoreCase(targetLang)) {
                        return text;
                }
                return translationService.translate(text, sourceLang, targetLang).orElse(text);
        }
}